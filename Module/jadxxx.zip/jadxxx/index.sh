
#lang
if [ "$locale" == "vi_VN" ];then
title="Jadx"
desc="Trình dịch ngược Dex sang Java"
xoamd="Xóa mô-đun"
huymd="Hủy xóa"
upmd="Cập nhật jadx"
ndhhf="Cập nhật hoàn tất"
idbhd="Đã hủy xóa thành công"
kxbdb="Đã thêm vào danh sách xóa"
else
title="Jadx"
desc="Dex to Java decompiler"
xoamd="Delete module"
huymd="Cancel delete"
upmd="Jadx updates"
ndhhf="Update is complete"
idbhd="Canceled delete successfully"
kxbdb="Added to the deletion list"
fi


cat <<EOF
<group>
<page config-sh="echo \$MODULE_PATH/jadxxx/home-\$locale.xml" id="jadx" >
<title>$title</title>
<desc>$desc</desc>
<option type="default" id="update" suffix="zip" type="file" auto-off="true">$upmd</option>
<option type="default" id="huy" auto-off="true">$huymd</option>
<option type="default" id="xoa" auto-off="true" auto-finish="true">$xoamd</option>
<handler>
if [ "\$menu_id" == "xoa" ];then
echo 'delete' > \$MODULE_PATH/jadxxx/delete
echo "$kxbdb"
elif [ "\$file" ];then
rm -fr \$MODULE_PATH/jadxxx/jadx/*
unzip -oq "\$file" -d \$MODULE_PATH/jadxxx/jadx
echo "$ndhhf"
else
rm -fr \$MODULE_PATH/jadxxx/delete
echo "$idbhd"
fi
</handler>
</page>
</group>
EOF
