
locale=$(getprop persist.sys.locale|awk -F "-" '{print $1"_"$NF}')
  [[ ${locale} == "" ]] && locale=$(settings get system system_locales|awk -F "," '{print $1}'|awk -F "-" '{print $1"_"$NF}')

lang="${0%/*}/$locale.vi"
xml="${0%/*}/*.xml"
cp -rf ${0%/*}/xml/*.xml ${0%/*}
cp -rf ${0%/*}/lang/$locale.vi ${0%/*}

until [ "$(grep -c "#" $lang)" == 0 ];do
tim=$(grep -m1 "#" $lang | cut -d "#" -f1)
thay=$(grep -m1 "#" $lang | cut -d "#" -f2)
sed -i "s|$tim|$thay|g" $xml
sed -i '1d' $lang
done
rm -fr $lang



