echo '<?xml version="1.0" encoding="UTF-8" ?>'
for var in $(find $START_DIR/data/module/ -name index.xml);do
cd $(echo "$var" | sed 's|index.xml||g')
if [ -e "./index-$locale.xml" ];then
cat ./index-$locale.xml
else
cat ./index.xml
fi
echo
done