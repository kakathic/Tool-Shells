echo '<?xml version="1.0" encoding="UTF-8" ?>'
echo '<text/>
<text>
<slice color="#1CA4FF" size="20">Installed</slice>
</text>'
echo '<group>'
for var in $(find $START_DIR/data/module/ -name index.xml);do
cd $(echo "$var" | sed 's|index.xml||g')
if [ -e "$(echo "$var" | sed 's|index.xml||g')delete" ];then
rm -fr "$(echo "$var" | sed 's|index.xml||g')"
fi
if [ -e "./index-$locale.xml" ];then
cat ./index-$locale.xml
else
cat ./index.xml
fi
if [ -e "./index.sh" ];then
sh ./index.sh
fi
echo
done
echo '</group>'

timeout 5 curl -Gs https://raw.githubusercontent.com/kakathic/Tool-Tool/master/Module/README.md 2>/dev/null