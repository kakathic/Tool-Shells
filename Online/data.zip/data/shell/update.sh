echo "Check for updates xml"
vmenu=$(curl -Gs https://raw.githubusercontent.com/kakathic/Tool-Terminal/master/Online/README.md | grep "Menu=" | cut -d "=" -f2)
ssmenu=$(getvb Menu)
if [ "$vmenu" ];then
if [ "$vmenu" == "$ssmenu" ];then
echo "No updates"
echo
else
echo "Installing xml updates"
curl -Ls "https://github.com/kakathic/Tool-Terminal/raw/master/Online/data.zip" -o $START_DIR/data.zip 2>/dev/null
unzip -oq $START_DIR/data.zip -d $START_DIR
rm -fr $START_DIR/data.zip

if [ -e "$START_DIR/data/lang/$locale.vi" ];then
cp -rf $START_DIR/data/lang/$locale.vi $START_DIR/data
lang="$START_DIR/data/$locale.vi"
else
cp -rf $START_DIR/data/lang/en_US.vi $START_DIR/data
lang="$START_DIR/data/en_US.vi"
fi

xml="$START_DIR/data/*.xml"
cp -rf $START_DIR/data/xml/*.xml $START_DIR/data

until [ "$(grep -c "#" $lang)" == 0 ];do
tim=$(grep -m1 "#" $lang | cut -d "#" -f1)
thay=$(grep -m1 "#" $lang | cut -d "#" -f2)
$TOOLKIT/sed -i "s|$tim|$thay|g" $xml
$TOOLKIT/sed -i '1d' $lang
done
rm -fr $lang

fi
else
echo "Network error"
exit
fi

echo "Check for updates data"
tooltar=$(curl -Gs https://raw.githubusercontent.com/kakathic/Tool-Terminal/master/Online/README.md | grep "Tooltar=" | cut -d "=" -f2)
sstar=$(getvb Tooltar)
if [ "$tooltar" == "$sstar" ];then
echo "No updates"
echo
else
echo "Installing data updates"

$TOOLKIT/wget -q https://github.com/kakathic/Tool-Terminal/releases/download/Tool_$tooltar/Tool2.tar.xz -O $START_DIR/Tool2 2>/dev/null
tar -xJf $START_DIR/Tool2 -C $START_DIR/kr-script
rm -fr $START_DIR/Tool2

baksmali=`echo 'https://bitbucket.org'$(curl -Gs https://bitbucket.org/JesusFreke/smali/downloads/ | grep -m 1 "/baksmali-" | cut -d "\"" -f 2)''`
smali=`echo 'https://bitbucket.org'$(curl -Gs https://bitbucket.org/JesusFreke/smali/downloads/ | grep -m 1 "/smali-" | cut -d "\"" -f 2)''`
tenm1=$(ls -1 $LIB/baksmali)
tenm2=$(ls -1 $LIB/smali)
temb1=$(echo $baksmali | tr "/" "\n" | grep "baksmali-")
temb2=$(echo $smali | tr "/" "\n" | grep "smali-")
if [ "$tenm1" == "$temb1" ];then
echo >/dev/null
elif [ "$baksmali" ];then
echo
echo "Baksmali update"
rm -fr $LIB/baksmali/*
cd $LIB/baksmali
curl -LOs "$baksmali" 2>/dev/null
echo
echo "Smali update"
rm -fr $LIB/smali/*
cd $LIB/smali
curl -LOs "$smali" 2>/dev/null
else
echo
echo 'Network error'
fi


fi

echo "Check for updates java"
tooljdk=$(curl -Gs https://raw.githubusercontent.com/kakathic/Tool-Terminal/master/Online/README.md | grep "JDK=" | cut -d "=" -f2)
ssjdk=$(getvb jdk)
if [ "$tooljdk" == "$ssjdk" ];then
echo "No updates"
echo
else
echo "Installing java updates"
$TOOLKIT/wget -q https://github.com/kakathic/Tool-Terminal/releases/download/Tool_$tooljdk/JDK-$CPU -O $START_DIR/JDK 2>/dev/null
tar -xJf $START_DIR/JDK -C $FHOME
rm -fr $START_DIR/JDK
fi

echo "Check for updates glibc"
glibc=$(curl -Gs https://raw.githubusercontent.com/kakathic/Tool-Terminal/master/Online/README.md | grep "Glibc=" | cut -d "=" -f2)
kkglibc=$(getvb Glibc)
if [ "$glibc" == "$kkglibc" ];then
echo "No updates"
echo
else
echo "Installing Glibc updates"
$TOOLKIT/wget -q https://github.com/kakathic/Tool-Terminal/releases/download/Tool_$glibc/Tool-$CPU -O $START_DIR/Tool.tar.xz 2>/dev/null
tar -xJf $START_DIR/Tool.tar.xz -C $START_DIR/kr-script
cp -rf $LIB2/ld-linux-* $LIB
rm -fr $START_DIR/Tool.tar.xz
fi


chmod -R 755 $START_DIR
chown -R $APP_USER_ID:$APP_USER_ID $START_DIR 
