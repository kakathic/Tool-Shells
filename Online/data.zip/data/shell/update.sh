linkb="/data/data/com.kakathic.shells/files/kr-script/toolkit"
vmenu=$(curl -Gs https://raw.githubusercontent.com/kakathic/Tool-Tool/master/Online/README.md | grep "Menu=" | cut -d "=" -f2)
ssmenu=$(cat $linkb/menu.txt 2>/dev/null)

if [ "$vmenu" ];then
if [ "$vmenu" == "$ssmenu" ];then
tooltar=$(curl -Gs https://raw.githubusercontent.com/kakathic/Tool-Tool/master/Online/README.md | grep "Tooltar=" | cut -d "=" -f2)
sstar=$(cat $linkb/sstar.txt 2>/dev/null)
if [ "$tooltar" == "$sstar" ];then
tooljdk=$(curl -Gs https://raw.githubusercontent.com/kakathic/Tool-Tool/master/Online/README.md | grep "JDK=" | cut -d "=" -f2)
ssjdk=$(cat $linkb/ssjdk.txt 2>/dev/null)
if [ "$tooljdk" == "$ssjdk" ];then
echo "No updates"
else
echo "✓ Updates"
fi
else
echo "✓ Updates"
fi
else
echo "✓ Updates"
fi
else
echo "Network error"
fi