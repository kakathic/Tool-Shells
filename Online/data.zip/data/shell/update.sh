
vmenu=$(curl -Gs https://raw.githubusercontent.com/kakathic/Tool-Tool/master/Online/README.md | grep "Menu=" | cut -d "=" -f2)
ssmenu=$(cat $TOOLKIT/README.md | grep "Menu=" | cut -d "=" -f2)

if [ "$vmenu" ];then
if [ "$vmenu" == "$ssmenu" ];then
tooltar=$(curl -Gs https://raw.githubusercontent.com/kakathic/Tool-Tool/master/Online/README.md | grep "Tooltar=" | cut -d "=" -f2)
sstar=$(cat $TOOLKIT/README.md | grep "Tooltar=" | cut -d "=" -f2)
if [ "$tooltar" == "$sstar" ];then
tooljdk=$(curl -Gs https://raw.githubusercontent.com/kakathic/Tool-Tool/master/Online/README.md | grep "JDK=" | cut -d "=" -f2)
ssjdk=$(cat $TOOLKIT/README.md | grep "JDK=" | cut -d "=" -f2)
if [ "$tooljdk" == "$ssjdk" ];then
echo "No updates"
exit
else
echo >/dev/null
fi
else
echo >/dev/null
fi
else
echo >/dev/null
fi
else
echo "Network error"
exit
fi